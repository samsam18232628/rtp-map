package com.rtpmapper;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class RtpMapperScreen extends Screen {

    private static final int COLOR_BG = 0xE60A0E17;
    private static final int COLOR_PANEL = 0xFF0D1420;
    private static final int COLOR_LINE = 0xFF1C2940;
    private static final int COLOR_RING = 0xFF3A5570;
    private static final int COLOR_TEXT_DIM = 0xFF6C8299;
    private static final int COLOR_CYAN = 0xFF5EC8E8;
    private static final int COLOR_OK = 0xFF4A90FF;
    private static final int COLOR_BLOCKED = 0xFFFF5C5C;

    public RtpMapperScreen() {
        super(Text.literal("RTP Mapper"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, COLOR_BG);

        context.drawCenteredTextWithShadow(this.textRenderer,
                "RTP MAPPER  —  ' to close, F6 log OK, F7 log blocked",
                this.width / 2, 12, COLOR_CYAN);

        List<RtpPoint> points = RtpMapperClient.POINTS;

        // stats panel, left side
        int panelX = 16, panelY = 34, panelW = 150;
        drawStats(context, points, panelX, panelY, panelW);

        // plot area, remaining space
        int plotX = panelX + panelW + 20;
        int plotY = 34;
        int plotSize = Math.min(this.width - plotX - 16, this.height - plotY - 16);
        drawPlot(context, points, plotX, plotY, plotSize);

        super.render(context, mouseX, mouseY, delta);
    }

    private void drawStats(DrawContext context, List<RtpPoint> points, int x, int y, int w) {
        context.fill(x, y, x + w, y + this.height - y - 16, COLOR_PANEL);
        context.drawHorizontalLine(x, x + w, y, COLOR_LINE);

        int line = y + 10;
        context.drawText(this.textRenderer, "STATUS", x + 8, line, COLOR_CYAN, false);
        line += 14;

        long ok = points.stream().filter(RtpPoint::isOk).count();
        long blocked = points.size() - ok;

        context.drawText(this.textRenderer, "Total: " + points.size(), x + 8, line, COLOR_TEXT_DIM, false);
        line += 11;
        context.drawText(this.textRenderer, "Landed: " + ok, x + 8, line, COLOR_OK, false);
        line += 11;
        context.drawText(this.textRenderer, "Blocked: " + blocked, x + 8, line, COLOR_BLOCKED, false);
        line += 18;

        if (!points.isEmpty()) {
            double meanX = points.stream().mapToDouble(RtpPoint::x).average().orElse(0);
            double meanZ = points.stream().mapToDouble(RtpPoint::z).average().orElse(0);
            double meanR = points.stream().mapToDouble(p -> Math.hypot(p.x(), p.z())).average().orElse(0);

            context.drawText(this.textRenderer, "STATS", x + 8, line, COLOR_CYAN, false);
            line += 14;
            context.drawText(this.textRenderer, "Mean X: " + (int) meanX, x + 8, line, COLOR_TEXT_DIM, false);
            line += 11;
            context.drawText(this.textRenderer, "Mean Z: " + (int) meanZ, x + 8, line, COLOR_TEXT_DIM, false);
            line += 11;
            context.drawText(this.textRenderer, "Mean radius: " + (int) meanR, x + 8, line, COLOR_TEXT_DIM, false);
        } else {
            context.drawText(this.textRenderer, "No points logged yet.", x + 8, line, COLOR_TEXT_DIM, false);
            line += 11;
            context.drawText(this.textRenderer, "Press F6/F7 in-game.", x + 8, line, COLOR_TEXT_DIM, false);
        }
    }

    private void drawPlot(DrawContext context, List<RtpPoint> points, int x, int y, int size) {
        context.fill(x, y, x + size, y + size, COLOR_PANEL);

        int cx = x + size / 2;
        int cy = y + size / 2;

        // axis lines through center
        context.drawHorizontalLine(x, x + size, cy, COLOR_LINE);
        context.drawVerticalLine(cx, y, y + size, COLOR_LINE);

        double maxAbs = 1000;
        for (RtpPoint p : points) {
            maxAbs = Math.max(maxAbs, Math.max(Math.abs(p.x()), Math.abs(p.z())));
        }
        maxAbs *= 1.15;

        double halfPlot = size / 2.0 - 12;
        double scale = halfPlot / maxAbs;

        // concentric rings, dashed via small dots
        int rings = 4;
        for (int i = 1; i <= rings; i++) {
            double r = halfPlot * i / rings;
            for (int deg = 0; deg < 360; deg += 6) {
                double rad = Math.toRadians(deg);
                int px = (int) (cx + Math.cos(rad) * r);
                int py = (int) (cy + Math.sin(rad) * r);
                context.fill(px, py, px + 1, py + 1, COLOR_RING);
            }
            String label = (int) (maxAbs * i / rings) + "";
            context.drawText(this.textRenderer, label, cx + 4, (int) (cy - r), COLOR_TEXT_DIM, false);
        }

        // points
        for (RtpPoint p : points) {
            int px = (int) (cx + p.x() * scale);
            int py = (int) (cy + p.z() * scale);
            int color = p.isOk() ? COLOR_OK : COLOR_BLOCKED;
            int r = p.isOk() ? 1 : 2;
            context.fill(px - r, py - r, px + r + 1, py + r + 1, color);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
