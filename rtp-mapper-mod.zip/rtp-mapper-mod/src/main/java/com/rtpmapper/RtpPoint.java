package com.rtpmapper;

public record RtpPoint(double x, double z, String outcome) {
    public boolean isOk() {
        return "ok".equals(outcome);
    }
}
