package com.rtpmapper;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Client-only mod. Watches your OWN client-side player position each tick.
 * When it jumps by more than TELEPORT_THRESHOLD blocks in one tick (a real
 * RTP-style teleport, not normal movement), it auto-logs the new X/Z as
 * "ok". It never sends /rtp, never reads server packets, and never acts on
 * the server in any way — it only observes your own local position.
 */
public class RtpMapperClient implements ClientModInitializer {

    private static final Path OUTPUT_DIR =
            net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("rtp-mapper");
    private static final Path OUTPUT_FILE = OUTPUT_DIR.resolve("points.csv");

    /** Any single-tick move farther than this (blocks) is treated as a teleport, not walking/flying. */
    private static final double TELEPORT_THRESHOLD = 300.0;

    public static final List<RtpPoint> POINTS = new ArrayList<>();

    private KeyBinding manualLogKey;
    private KeyBinding markBlockedKey;
    private KeyBinding openMapKey;

    private Double prevX = null;
    private Double prevZ = null;
    private String prevDimension = null;

    @Override
    public void onInitializeClient() {
        manualLogKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rtp-mapper.manual_log", GLFW.GLFW_KEY_F6, "category.rtp-mapper"));

        markBlockedKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rtp-mapper.mark_blocked", GLFW.GLFW_KEY_F7, "category.rtp-mapper"));

        openMapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rtp-mapper.open_map", GLFW.GLFW_KEY_APOSTROPHE, "category.rtp-mapper"));

        ensureFileExists();
        loadExistingPoints();

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            prevX = null;
            prevZ = null;
            return;
        }

        double x = client.player.getX();
        double z = client.player.getZ();
        String dimension = client.world.getRegistryKey().getValue().toString();

        if (prevX != null && dimension.equals(prevDimension)) {
            double dx = x - prevX;
            double dz = z - prevZ;
            double distSq = dx * dx + dz * dz;
            if (distSq > TELEPORT_THRESHOLD * TELEPORT_THRESHOLD) {
                logPoint(client, x, z, "ok", true);
            }
        }

        prevX = x;
        prevZ = z;
        prevDimension = dimension;

        while (manualLogKey.wasPressed()) {
            logPoint(client, client.player.getX(), client.player.getZ(), "ok", false);
        }
        while (markBlockedKey.wasPressed()) {
            markLastAsBlocked(client);
        }
        while (openMapKey.wasPressed()) {
            if (client.currentScreen == null) {
                client.setScreen(new RtpMapperScreen());
            }
        }
    }

    private void ensureFileExists() {
        try {
            Files.createDirectories(OUTPUT_DIR);
            if (!Files.exists(OUTPUT_FILE)) {
                Files.writeString(OUTPUT_FILE, "x,z,outcome,note,timestamp\n", StandardOpenOption.CREATE);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadExistingPoints() {
        try {
            List<String> lines = Files.readAllLines(OUTPUT_FILE);
            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",", -1);
                if (parts.length < 3) continue;
                try {
                    double x = Double.parseDouble(parts[0]);
                    double z = Double.parseDouble(parts[1]);
                    POINTS.add(new RtpPoint(x, z, parts[2]));
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void logPoint(MinecraftClient client, double x, double z, String outcome, boolean auto) {
        RtpPoint point = new RtpPoint(x, z, outcome);
        POINTS.add(point);
        appendLine(point);

        if (client.player != null) {
            Formatting color = outcome.equals("ok") ? Formatting.AQUA : Formatting.RED;
            String prefix = auto ? "[RTP Mapper] Auto-logged: " : "[RTP Mapper] Logged: ";
            client.player.sendMessage(
                    Text.literal(prefix).append(Text.literal(String.format("%.0f, %.0f", x, z)).formatted(color)),
                    true
            );
        }
    }

    /** F7: re-labels the most recent point as blocked/redirected, since only you know that from context. */
    private void markLastAsBlocked(MinecraftClient client) {
        if (POINTS.isEmpty()) return;
        RtpPoint last = POINTS.get(POINTS.size() - 1);
        POINTS.set(POINTS.size() - 1, new RtpPoint(last.x(), last.z(), "blocked"));
        rewriteFile();

        if (client.player != null) {
            client.player.sendMessage(
                    Text.literal("[RTP Mapper] Marked last point as blocked.").formatted(Formatting.RED),
                    true
            );
        }
    }

    private void appendLine(RtpPoint point) {
        try {
            String line = String.format("%.1f,%.1f,%s,,%s%n",
                    point.x(), point.z(), point.outcome(), Instant.now());
            Files.writeString(OUTPUT_FILE, line, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void rewriteFile() {
        try {
            StringBuilder sb = new StringBuilder("x,z,outcome,note,timestamp\n");
            for (RtpPoint p : POINTS) {
                sb.append(String.format("%.1f,%.1f,%s,,%s%n", p.x(), p.z(), p.outcome(), Instant.now()));
            }
            Files.writeString(OUTPUT_FILE, sb.toString(), StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
