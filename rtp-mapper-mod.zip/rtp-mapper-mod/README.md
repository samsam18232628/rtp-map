# RTP Mapper (Fabric client mod)

Watches your OWN client-side position every tick. When it jumps more than
300 blocks in a single tick — a real teleport, not walking or flying — it
auto-logs the new X/Z as "ok" and appends it to a CSV file. It does not
send `/rtp`, does not read server packets, and never acts on the server;
it only observes your own local position, the same value your F3 screen
already shows you.

## What it does
- **Automatic** — any teleport-sized position jump is logged as "ok" with
  no key needed.
- **F7** — re-labels the *most recent* point as "blocked / redirected".
  The mod can't tell intent from position alone, so if you got redirected
  (e.g. sent to a claimed-land fallback spot) instead of a real random
  landing, press F7 right after to correct that last entry.
- **F6** — manual fallback log, in case a teleport is somehow missed (e.g.
  right after logging in).
- **'** (apostrophe) — opens an in-game map screen (press ESC or ' again to
  close). It plots every logged point as a radar-style chart with rings and
  a stats panel (total, landed, blocked, mean X/Z, mean radius) — same idea
  as the web version, rendered directly with Minecraft's own GUI drawing,
  no external files needed to view it.
- All three keys are rebindable in Options → Controls → RTP Mapper.
- Points are appended to:
  `.minecraft/config/rtp-mapper/points.csv`
  in the same format the web mapper tool exports
  (`x,z,outcome,note,timestamp`), so you can open that file, copy rows,
  and paste them into the web tool's Add Point flow, or just read the CSV
  directly.

## Build it
Requires: JDK 21, and either IntelliJ IDEA with the Minecraft Development
plugin, or the command line.

1. Unzip this folder.
2. Check `gradle.properties` — the Minecraft/Yarn/Loader/Fabric API
   versions there target 1.21.1. If your client runs a different 1.21.x
   patch, update those four lines to match (see fabricmc.net/develop for
   current numbers for your version).
3. From the project folder:
   ```
   ./gradlew build
   ```
   (On Windows: `gradlew.bat build`)
4. The built jar appears in `build/libs/rtp-mapper-1.0.0.jar`.
5. Install [Fabric Loader](https://fabricmc.net/use/) for your Minecraft
   version if you haven't already, then drop `rtp-mapper-1.0.0.jar` and
   the matching **Fabric API** jar into your real `.minecraft/mods/`
   folder. Launch with the Fabric profile.

## Notes
- This is unsigned, unpublished, from-scratch source — nothing here was
  downloaded from a mod site, so there's nothing to scan/trust but your
  own build of it.
- If DonutSMP's rules restrict client mods, check their rules before
  joining with this installed — this only reads your own local position
  (the same thing your F3 screen already shows you), but it's still your
  call to confirm it's allowed.
